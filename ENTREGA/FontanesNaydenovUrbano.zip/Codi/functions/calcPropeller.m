function n = calcPropeller(ETA, J, v0, D)
n =  v0/(D*J);
end