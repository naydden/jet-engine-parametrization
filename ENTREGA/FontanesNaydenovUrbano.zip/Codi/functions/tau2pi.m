function [ PI ] = tau2pi( TAU,gam)
%tau2pi From tau to pi values
PI = TAU^(gam/(gam-1));


end

