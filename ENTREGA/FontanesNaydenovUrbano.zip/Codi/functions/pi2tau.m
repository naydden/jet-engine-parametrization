function [ TAU ] = pi2tau( PI,gam )
%tau2pi From tau to pi values
TAU = PI^((gam-1)/gam);


end
